#!/bin/bash
D=/home/harvest/hailo-bench2
bash $D/run_full.sh F8-n16 16 --batch 8 --inflight 3; sleep 5
bash $D/run_full.sh F1-n16 16 --batch 1 --inflight 8; sleep 5
bash $D/run_full.sh F1-n12 12 --batch 1 --inflight 8
echo FULL_DONE >> $D/results/full.log
