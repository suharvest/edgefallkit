#!/bin/bash
D=/home/harvest/hailo-bench2; R=$D/results
( sleep 90; P=$(pgrep -f "[b]ench_c.py.*F1k16-n16" | head -1); top -H -b -n 2 -d 3 -p $P | awk "/^top/{n++} n==2" | head -40 > $R/F1k16-n16.topH.txt; top -b -n 2 -d 3 | awk "/^top/{n++} n==2" | head -30 > $R/F1k16-n16.top.txt ) &
bash $D/run_full.sh F1k16-n16 16 --batch 1 --inflight 16 --post-threads 2
echo FULL2_DONE >> $R/full.log
